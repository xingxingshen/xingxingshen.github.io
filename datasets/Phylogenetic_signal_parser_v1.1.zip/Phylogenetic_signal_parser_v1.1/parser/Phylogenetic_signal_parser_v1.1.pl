#!/usr/bin/perl
use strict;
use warnings;
#usage: perl Phylogenetic_signal_parser.pl RAxML_perSiteLLs.284genes_turtes_site_lk combing_orders.txt Yes or No turtes#
my $start_time=time;
my $infile=$ARGV[0]; # Site_wise loglikelihood file estimated from RAxML #
my $gene_boundary=$ARGV[1]; # Gene-based partition file in RAxML-style #
my $site_wise_out=$ARGV[2]; # Do you want to print site-wise log likelihood output? Yes or NO #
my $out_file=$ARGV[3]; #  prefix for outfile(s) #
#next unless $infile=~m/RAxML_perSiteLLs.(?<branch>.*)/gi;
my $branch_name=$out_file;
my %gene_position;
open (MATCHIN, $gene_boundary) or die "Can't open the file $gene_boundary: $!";
  while (my $content=<MATCHIN>) { 
	chomp $content;
	$content=~s/ //g;
 	next unless $content=~m/.*,(?<id>.+?)=(?<start>\d+)-(?<end>\d+)/gi;
    my $gene_name=$+{id};
    my $gene_start=$+{start};
    my $gene_end=$+{end};
    my @gene_sites=($gene_start..$gene_end);
	my $rela_position=0;
    foreach  my $gene_site( @gene_sites) {$rela_position++; @{$gene_position{$gene_site}}=($gene_name,$rela_position);}		 
  }
close MATCHIN;

my %site_hash;
my %biggest_site;
my $sites_no;
my @trees;
open (IN, $infile) or die "Can't open the file $infile: $!";
while (my $content=<IN>)  {
	 chomp $content;
	 $content=~s/\t+/ /gi;
	 #if ($content=~/^\d+\s+(\d+)/gi) {$sites_no=$1;}
	 next unless $content=~m/^(?<tre>t\w+\d+)\s+(?<lns>.*)/gi;
	 my $tree_name=$+{tre};
	 my $lns_content=$+{lns};
     my @site_lns=split(/\s+/,$lns_content); 
	 $tree_name=~s/tree/tr/gi;
	 push  @trees, $tree_name;
	 my $site=0;
     foreach my $site_ln (@site_lns) {
		  $site++;
		  push @{$site_hash{$site}}, $site_ln;

          ## recognize putative site with lighest value ##
		  if (exists $biggest_site{$site}) {
			  if ($site_ln>$biggest_site{$site}[1]) { @{$biggest_site{$site}}=($tree_name,$site_ln);}
		  }else{@{$biggest_site{$site}}=($tree_name,$site_ln);}

      }	 
}
close IN;

print "Reading your data...\n";
my $trees_no=scalar @trees;
if ($trees_no>3) { print "Please edit the scripts, since they only accept no more than 3 hypotheses";}

my $sites_no_in_gene_partition=scalar keys %gene_position;
my $sites_no_in_sitelnlk=scalar keys %site_hash;
if ($sites_no_in_gene_partition<=>$sites_no_in_sitelnlk) { print "Please go to check $gene_boundary (has $sites_no_in_gene_partition sites) and $infile (has $sites_no_in_sitelnlk sites) files, they contain different numbers of sites\n";
}
else{
my %gene_hash;
foreach my $site (sort { $a <=> $b } keys %site_hash) {
   my $gene=$gene_position{$site}[0];

   if ($trees_no==2) {
     if (exists $gene_hash{$gene}) {
	 my $gene_ln_t1=$gene_hash{$gene}[0]+@{$site_hash{$site}}[0];
	 my $gene_ln_t2=$gene_hash{$gene}[1]+@{$site_hash{$site}}[1];
	 @{$gene_hash{$gene}}=($gene_ln_t1,$gene_ln_t2);
	 }else{@{$gene_hash{$gene}}=(@{$site_hash{$site}}[0], @{$site_hash{$site}}[1]);}
   }

   elsif ($trees_no==3) {
     if (exists $gene_hash{$gene}) {
	 my $gene_ln_t1=$gene_hash{$gene}[0]+@{$site_hash{$site}}[0];
	 my $gene_ln_t2=$gene_hash{$gene}[1]+@{$site_hash{$site}}[1];
	 my $gene_ln_t3=$gene_hash{$gene}[2]+@{$site_hash{$site}}[2];
	 @{$gene_hash{$gene}}=($gene_ln_t1,$gene_ln_t2,$gene_ln_t3);
	 }else{@{$gene_hash{$gene}}=(@{$site_hash{$site}}[0], @{$site_hash{$site}}[1],@{$site_hash{$site}}[2]);}
   }

   if ($site_wise_out=~ m/Yes/i) {
	my $site_lns_list=join( ",", @{$site_hash{$site}} );
	$site_lns_list=~s/,/\t/g;
    my $out= "${branch_name}_Gene_${gene}_sitewise_lnL.txt";
    open (OUT,">>", $out) or die "Can't write the file $out: $!";
    print OUT "$gene\t$site\t$gene_position{$site}[1]\t$biggest_site{$site}[0]\t@trees\t$site_lns_list\n"; 
    close OUT;
  }

}

if ($trees_no==2) {
    my $output= "${branch_name}_genewise_lnL.txt";
   open (OUTPUT,">>", $output) or die "Can't write the file $output: $!";
   print OUTPUT "gene_id\ttree_supported\ttr1_log-likelihood\ttr2_log-likelihood\n";
   foreach my $gene (sort { $a cmp $b  } keys %gene_hash) { 
    if ($gene_hash{$gene}[0]>$gene_hash{$gene}[1]) { print OUTPUT "$gene\ttr1\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\n"; }
    elsif ($gene_hash{$gene}[1]>$gene_hash{$gene}[0]) { print OUTPUT "$gene\ttr2\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\n"; }
   } 
  close OUTPUT;
}

elsif ($trees_no==3) {
   my $output= "${branch_name}_genewise_lnL.txt";
   open (OUTPUT,">>", $output) or die "Can't write the file $output: $!";
   print OUTPUT "gene_id\ttree_supported\ttr1_log-likelihood\ttr2_log-likelihood\ttr3_log-likelihood\n";
   foreach my $gene (sort { $a cmp $b  } keys %gene_hash) { 
    if ($gene_hash{$gene}[0]>$gene_hash{$gene}[1] and $gene_hash{$gene}[0]>$gene_hash{$gene}[2]) { print OUTPUT "$gene\ttr1\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t$gene_hash{$gene}[2]\n"; }
    elsif ($gene_hash{$gene}[1]>$gene_hash{$gene}[0] and $gene_hash{$gene}[1]>$gene_hash{$gene}[2]) { print OUTPUT "$gene\ttr2\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t$gene_hash{$gene}[2]\n"; }
    elsif ($gene_hash{$gene}[2]>$gene_hash{$gene}[0] and $gene_hash{$gene}[2]>$gene_hash{$gene}[1]) { print OUTPUT "$gene\ttr3\t$gene_hash{$gene}[0]\t$gene_hash{$gene}[1]\t$gene_hash{$gene}[2]\n"; }
   } 
  close OUTPUT;
}


}


if ($site_wise_out=~ m/Yes/i) {
	 my @infiles=glob("${branch_name}_*_sitewise_lnL.txt");
     foreach my $infile (@infiles) {
     next unless $infile=~m/(?<branch>.+?)_Gene_(?<gene>.+?)_sitewise_lnL.txt/gi;
     my $branch_id=$+{branch};
     my $gene_id=$+{gene};
     my %hash;
     my $tree_no;
     print "$branch_id\t$gene_id\n";  
     open (MATCHIN, $infile) or die "Can't open the file $infile: $!";
    while (my $content=<MATCHIN>) { 
	chomp $content;
    my @elements=split(/\t+/,$content);
    my $best_tree=$elements[3];
	my @trees=split(/\s+/,$elements[4]);
    $tree_no=scalar @trees;
	my $site_signal;
	if ($tree_no==3) {$site_signal=(abs($elements[5]-$elements[6])+abs($elements[5]-$elements[7])+abs($elements[6]-$elements[7]))/3;}
	elsif ($tree_no==2) {$site_signal=abs($elements[5]-$elements[6])};
	@{$hash{$elements[1]}}=($site_signal, $best_tree);
   }
   close MATCHIN;

   if ($tree_no>3) { print "Please edit the scripts, since they only accept no more than 3 hypotheses";}

   if ($tree_no==2) {
   my $t1_0_no=0;
   my $t2_0_no=0;
   my $t1_weak_no=0;
   my $t2_weak_no=0;
   my $t1_strong_no=0;
   my $t2_strong_no=0;
   foreach  my $site( sort { $a <=> $b } keys %hash) {	
	   if ($hash{$site}[1] eq "tr1") {$t1_0_no++;}
	   if ($hash{$site}[1] eq "tr2") {$t2_0_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]<=0.5) {$t1_weak_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]<=0.5) {$t2_weak_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]>0.5) {$t1_strong_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]>0.5) {$t2_strong_no++;}

   }
   my $output= "${branch_id}_sitewise_statictics.table";
   open (OUT,">>", $output) or die "Can't write the file $output: $!";
   print OUT "$gene_id\tall\ttr1 tr2\t$t1_0_no\t$t2_0_no\n";
   print OUT "$gene_id\tweak\ttr1 tr2\t$t1_weak_no\t$t2_weak_no\n";
   print OUT "$gene_id\tstrong\ttr1 tr2\t$t1_strong_no\t$t2_strong_no\n";
   close OUT;
   }

  if ($tree_no==3) {
   my $t1_0_no=0;
   my $t2_0_no=0;
   my $t3_0_no=0;
   my $t1_weak_no=0;
   my $t2_weak_no=0;
   my $t3_weak_no=0;
   my $t1_strong_no=0;
   my $t2_strong_no=0;
   my $t3_strong_no=0;
   foreach  my $site( sort { $a <=> $b } keys %hash) {	
	   if ($hash{$site}[1] eq "tr1") {$t1_0_no++;}
	   if ($hash{$site}[1] eq "tr2") {$t2_0_no++;}
	   if ($hash{$site}[1] eq "tr3") {$t3_0_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]<=0.5) {$t1_weak_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]<=0.5) {$t2_weak_no++;}
	   if ($hash{$site}[1] eq "tr3" && @{$hash{$site}}[0]<=0.5) {$t3_weak_no++;}
	   if ($hash{$site}[1] eq "tr1" && @{$hash{$site}}[0]>0.5) {$t1_strong_no++;}
	   if ($hash{$site}[1] eq "tr2" && @{$hash{$site}}[0]>0.5) {$t2_strong_no++;}
	   if ($hash{$site}[1] eq "tr3" && @{$hash{$site}}[0]>0.5) {$t3_strong_no++;}
   }
   my $output= "${branch_id}_sitewise_statictics.table";
   open (OUT,">>", $output) or die "Can't write the file $output: $!";
   print OUT "$gene_id\tall\ttr1 tr2 tr3\t$t1_0_no\t$t2_0_no\t$t3_0_no\n";
   print OUT "$gene_id\tweak\ttr1 tr2 tr3\t$t1_weak_no\t$t2_weak_no\t$t3_weak_no\n";
   print OUT "$gene_id\tstrong\ttr1 tr2 tr3\t$t1_strong_no\t$t2_strong_no\t$t3_strong_no\n";
   close OUT;
   }
 }
unlink glob("${branch_name}_*_sitewise_lnL.txt");
}
print "done\n";

my $end_time=time;
my $duration=($end_time-$start_time)/60;
print"Execution time: $duration min.\n";
